#include "AudioShield.h"

/**********************************************************
 * Vorinstantiiertes Objekt des MP3-Decoders (Klasse VS10XX)
 **********************************************************/
VS10XX VS1011;

