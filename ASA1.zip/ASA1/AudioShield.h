#ifndef AudioShield_h
#define AudioShield_h
#include <WProgram.h>
#include <utility/VS10xx.h>


/**********************************************************
 * Vorinstantiiertes Objekt des MP3-Decoders (Klasse VS10XX)
 **********************************************************/
extern VS10XX VS1011;

/******************************************************************************
 * Definitionen f?r Port-Pins des AudioShields
 * Zus?tzliche Funktionen welche nicht zum MP3-Decoder zugeh?ren.
 ******************************************************************************/
#define SD_CS 4
#define LED_BLUE A0
#define LED_RED A1
#define SD_POWER A2
#define SD_DETECT A3

#define LED_BLUE_ON digitalWrite(LED_BLUE, LOW)
#define LED_RED_ON digitalWrite(LED_RED, LOW)
#define LED_BLUE_OFF digitalWrite(LED_BLUE, HIGH)
#define LED_RED_OFF digitalWrite(LED_RED, HIGH)
#define SD_POWER_ON digitalWrite(SD_POWER, LOW)
#define SD_POWER_OFF digitalWrite(SD_POWER, HIGH)

#define CHECK_SD_DETECT digitalRead(SD_DETECT)

#endif /* AudioShield_h */
